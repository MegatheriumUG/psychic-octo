var AutoDNS = require('autodns');

module.exports = new AutoDNS('2015_02_19_bories_th', 'domain', 1, 'de', 'martin.bories@dressiety.de', 'https://demo.autodns.com/gateway/');