module.exports = {
	db: {
		ip: '37.120.171.46',
		port: '27017',
		db: 'psychic-octo'
	},
	GIT_REPOSITORY_DIRECTORY: './data/repositories/',
	PASSWORD_SALT_WORK_FACTOR: 10,
	PICTURE_DIRECTORY: './data/image/'
};